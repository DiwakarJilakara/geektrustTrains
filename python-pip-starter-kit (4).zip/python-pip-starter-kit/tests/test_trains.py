from src.models import trains1
import unittest
class test_trains(unittest.TestCase):
    def setUp(self) -> None:
        TrainA=[]
        TrainB=[]
        TrainAB=[]
        return super().setUp()
    def test_Train_Detach_A_Boggie_For_TrainA(self):
        TrainA=['SLM','HYB','GHY']
        TrainB=[]
        t=trains1.TrainJourney1()
        TrainA,TrainB,TrainAB=t.get_trains_information(TrainA,TrainB)
        self.assertListEqual(TrainA,['GHY'])
    def test_Train_Detach_A_Boggie_For_TrainB(self):
        TrainA=['SLM','HYB']
        TrainB=['TVC','TVC','MAO','HYB','NGP','NGP']
        t=trains1.TrainJourney1()
        TrainA,TrainB,TrainAB=t.get_trains_information(TrainA,TrainB)
        self.assertListEqual(TrainB,['NGP','NGP'])
    def test_Train_AB_With_Oneormore_Boggies_To_Travell(self):
        TrainA=['SLM','HYB','GHY']
        TrainB=['TVC','TVC','MAO','HYB','NJP','GHY']
        t=trains1.TrainJourney1()
        TrainA,TrainB,TrainAB=t.get_trains_information(TrainA,TrainB)
        self.assertListEqual(TrainAB,['GHY','GHY','NJP'])
    def test_Train_AB_With_Oneormore_Boggies_To_Travell2(self):
        TrainA=['SLM','HYB','GHY']
        TrainB=['TVC','TVC','MAO','HYB','NJP','GHY']
        t=trains1.TrainJourney1()
        TrainA,TrainB,TrainAB=t.get_trains_information(TrainA,TrainB)
        self.assertListEqual(TrainA,['GHY'])
    def test_Train_AB_With_Oneormore_Boggies_To_Travell1(self):
        TrainA=['SLM','HYB','GHY','NJP']
        TrainB=['TVC','TVC','MAO','HYB']
        t=trains1.TrainJourney1()
        TrainA,TrainB,TrainAB=t.get_trains_information(TrainA,TrainB)
        self.assertListEqual(TrainA,['GHY','NJP'])
    def test_Train_AB_With_Oneormore_Boggies_To_Travell3(self):
        TrainA=['SLM','HYB','GHY','NJP']
        TrainB=['TVC','TVC','MAO','HYB']
        t=trains1.TrainJourney1()
        TrainA,TrainB,TrainAB=t.get_trains_information(TrainA,TrainB)
        self.assertListEqual(TrainA,['GHY','NJP'])
    def test_Train_AB_With_Oneormore_Boggies_To_Travell(self):
        TrainA=['SLM','HYB','GHY']
        TrainB=['TVC','TVC','MAO','HYB','NJP','GHY']
        TrainAB=[]
        t=trains1.TrainJourney1()
        TrainA,TrainB,TrainAB =t.get_trains_information(TrainA,TrainB)
        self.assertListEqual(TrainAB,['GHY','GHY','NJP'])
if __name__ ==  '__main__':
    unittest.main()
    